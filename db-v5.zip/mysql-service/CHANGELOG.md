# Changelog — mysql-service

## version 1.3.0
- **Fixed persistent OOMKill on secondaries** (`secondary-1-0`, exit 137 at ~8 min).
  Root cause: v4 reduced `group_replication_message_cache_size` to 32M (correct)
  but kept `requests` far below `limits` (150m/600Mi vs 600m/1024Mi), leaving the
  pod in **Burstable QoS**. On a 2-node × 2.4Gi cluster already carrying Redis and
  Postgres, the sum of all DB chart limits (~5.0Gi) exceeded total cluster RAM
  (4.8Gi), so mysqld was allowed to climb unconstrained toward its 1024Mi ceiling.
  The GR distributed-recovery spike during the initial secondary join (~8 min mark)
  crossed it. The cgroup killed the container with no warning — `messageCacheSize`
  was never the problem.
- `resources`: **requests now equal limits** (primary 350m/850Mi, secondary
  300m/850Mi) — **true Guaranteed QoS**. Memory reserved up-front; no gap for
  transient spikes to exploit. Limit lowered from 1024Mi to 850Mi, which is
  sufficient for: mysqld base (~150MB) + InnoDB buffer pool 64M + InnoDB misc 80M
  + trimmed Performance Schema 40M + GR cache 32M + XCom structure overhead 50M
  + GR tracking + connections ≈ 470MB steady-state, leaving ~310MB for recovery
  spikes.
- `mysqlConfig`: `innodbBufferPoolSize: 96M → 64M`, `maxConnections: 30 → 20`,
  `tableOpenCache: 64 → 48` — trims ~40–60MB additional RSS headroom.
- **PVC retention policy** added to all StatefulSets (mysql primary, both
  secondaries; also postgres primary/standbys and redis primary/replicas for
  consistency): `whenDeleted: Retain, whenScaled: Retain`. Pod delete already
  retained PVCs by default; this explicitly protects data if the StatefulSet
  resource itself is deleted (e.g. `helm uninstall` without a prior manual
  `kubectl delete pvc`).
- **Faster bootstrap**: secondary primary-reachability wait loop tightened from
  40×5s (200s max) to 24×3s (72s max). GR join retry backoff reduced from
  5s/10s to 3s/6s. Realistic GR join now completes in ~2–3 min on this hardware
  instead of running up against the full 5 min readiness delay budget.
- **Liveness re-enabled** on all pods (was fully disabled in v4). New `liveness.sh`
  reads `/tmp/.container_start_time` (same marker as `readiness.sh`) and only
  checks `mysqladmin ping` — never checks MEMBER_STATE. This means a pod truly
  mid-GR-join is never restarted (mysqld is alive and responding), but a genuinely
  dead/hung mysqld process will still trigger a restart after `initialDelaySeconds
  (360s) + failureThreshold×period (6×20s = 120s) = 480s` — previously it would
  just sit broken forever since liveness was off.


- Fixed silent Group Replication failure: a secondary whose GR join failed
  (or was lost and never retried) could sit at `MEMBER_STATE=OFFLINE`
  indefinitely while `kubectl get pods` still showed `1/1 Running` — because
  the old `readiness.sh` only checked `mysqladmin ping`, never GR membership,
  and `bootstrap.sh` always `exit 0`'d regardless of whether the join
  actually succeeded. This meant a real 3-member group could silently
  degrade to 1 functioning member with no visible signal, so a later
  primary failover had no healthy secondary to elect.
- `readiness.sh` now checks `mysqladmin ping` immediately, then (after the
  same 360s startup grace period liveness.sh already used) also requires
  `MEMBER_STATE=ONLINE` from `performance_schema.replication_group_members`.
  A member stuck OFFLINE now shows `0/1` in `kubectl get pods`, not `1/1`.
- `bootstrap.sh` now launches a detached background watchdog on secondary
  pods that retries `START GROUP_REPLICATION` every 30s for the life of the
  container, instead of giving up permanently after ~5 minutes of initial
  retries. Combined with the readiness fix above, a member that misses its
  initial join window now self-heals and becomes visibly Ready again once
  it succeeds, rather than staying invisibly broken forever.

## version 1.1.0
- Fixed recurring OOMKill on the 2-node dev/test lab (`values-production.yaml`).
  Root cause: MySQL 8.0's default-sized Performance Schema buffers (statement
  history, wait history, digests) plus an oversized `table_open_cache=4000`
  add 150MB+ fixed RSS overhead independent of `innodb_buffer_pool_size`,
  which the previous 700Mi limit did not budget for.
  NOTE: `performance_schema` itself must stay ON — `bootstrap.sh` and
  `liveness.sh` in this chart query `performance_schema.replication_group_members`
  for GR membership/health, so fully disabling Performance Schema breaks
  failover detection entirely. The fix trims PS's internal buffer sizes
  instead of disabling the schema.
- Added `mysqlConfig.performanceSchemaConsumersOnlyGR`, `tableOpenCache`,
  `threadCacheSize` to `values.yaml`/`values-staging.yaml`/`values-production.yaml`
  and wired them into `templates/configmap.yaml` (base.cnf).
- `values-production.yaml`: `performanceSchemaConsumersOnlyGR: true`,
  `tableOpenCache: 64`, `threadCacheSize: 4`, memory request/limit raised
  400Mi/700Mi -> 450Mi/900Mi.
- `values-staging.yaml` / `values.yaml`: `performanceSchemaConsumersOnlyGR: false`
  (full-size PS buffers), `tableOpenCache: 4000` (unchanged — prod-grade
  nodes have headroom).

## version 1.0.0
- Standardised chart: uniform `multus` feature flag, `consul.serviceName`, ordered values.
- Cleaned values (Consul-sourced env removed, comments collapsed); logic preserved.
