# Changelog — mysql-service

## version 1.1.0
- Fixed recurring OOMKill on the 2-node dev/test lab (`values-production.yaml`).
  Root cause: MySQL 8.0's default-sized Performance Schema buffers (statement
  history, wait history, digests) plus an oversized `table_open_cache=4000`
  add 150MB+ fixed RSS overhead independent of `innodb_buffer_pool_size`,
  which the previous 700Mi limit did not budget for.
  NOTE: `performance_schema` itself must stay ON — `bootstrap.sh` and
  `liveness.sh` in this chart query `performance_schema.replication_group_members`
  for GR membership/health, so fully disabling Performance Schema breaks
  failover detection entirely. The fix trims PS's internal buffer sizes
  instead of disabling the schema.
- Added `mysqlConfig.performanceSchemaConsumersOnlyGR`, `tableOpenCache`,
  `threadCacheSize` to `values.yaml`/`values-staging.yaml`/`values-production.yaml`
  and wired them into `templates/configmap.yaml` (base.cnf).
- `values-production.yaml`: `performanceSchemaConsumersOnlyGR: true`,
  `tableOpenCache: 64`, `threadCacheSize: 4`, memory request/limit raised
  400Mi/700Mi -> 450Mi/900Mi.
- `values-staging.yaml` / `values.yaml`: `performanceSchemaConsumersOnlyGR: false`
  (full-size PS buffers), `tableOpenCache: 4000` (unchanged — prod-grade
  nodes have headroom).

## version 1.0.0
- Standardised chart: uniform `multus` feature flag, `consul.serviceName`, ordered values.
- Cleaned values (Consul-sourced env removed, comments collapsed); logic preserved.
