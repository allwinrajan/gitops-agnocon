# Database HA Helm Charts

Three production-grade Helm charts for Kubernetes: **MySQL** (Group Replication),
**PostgreSQL** (Streaming Replication + Hot Standby), and **Redis** (Sentinel HA).

All charts share the same design pattern: Consul Connect / Envoy sidecar, optional
Multus MacVLAN for direct LAN access, and robust `fix-routing` init containers
(policy routing tables 100 + 200) that prevent MacVLAN from hijacking cluster traffic.

---

## Environment Matrix

| File | Purpose | Multus | Consul | Resources | Storage |
|------|---------|--------|--------|-----------|---------|
| `values-production.yaml` | 2-node lab / CI failover test | OFF | OFF | Burstable (≤1 CPU/node) | `local-path` 1-2 Gi |
| `values-staging.yaml` | Full prod spec | ON | ON | Guaranteed QoS | `longhorn-*` 10-15 Gi |

> `values.yaml` is the base default; always layer an environment overlay on top.

---

## Deploy Commands

```bash
# MySQL — production (lab/test)
helm upgrade --install mysql-service ./mysql-service \
  -f mysql-service/values.yaml \
  -f mysql-service/values-production.yaml

# MySQL — staging (prod spec)
helm upgrade --install mysql-service ./mysql-service \
  -f mysql-service/values.yaml \
  -f mysql-service/values-staging.yaml

# PostgreSQL — production (lab/test)
helm upgrade --install postgres-service ./postgres-service \
  -f postgres-service/values.yaml \
  -f postgres-service/values-production.yaml

# PostgreSQL — staging (prod spec)
helm upgrade --install postgres-service ./postgres-service \
  -f postgres-service/values.yaml \
  -f postgres-service/values-staging.yaml

# Redis — production (lab/test)
helm upgrade --install redis-service ./redis-service \
  -f redis-service/values.yaml \
  -f redis-service/values-production.yaml

# Redis — staging (prod spec)
helm upgrade --install redis-service ./redis-service \
  -f redis-service/values.yaml \
  -f redis-service/values-staging.yaml
```

---

## Headless Service DNS (Pod-Direct Access)

All StatefulSets use a shared headless Service (`clusterIP: None`).
These FQDNs bypass kube-proxy and go directly to the pod — stable across pod restarts.

### MySQL (`mysql-cluster` namespace)

```
# Headless service name: mysql-headless
<release>-primary-0.mysql-headless.mysql-cluster.svc.cluster.local:3306
<release>-secondary-0-0.mysql-headless.mysql-cluster.svc.cluster.local:3306
<release>-secondary-1-0.mysql-headless.mysql-cluster.svc.cluster.local:3306

# GR XCOM (inter-member communication, not for client use)
<release>-primary-0.mysql-headless.mysql-cluster.svc.cluster.local:33061
<release>-secondary-0-0.mysql-headless.mysql-cluster.svc.cluster.local:33061
<release>-secondary-1-0.mysql-headless.mysql-cluster.svc.cluster.local:33061

# ClusterIP services (kube-proxy load-balanced)
<release>-primary.mysql-cluster.svc.cluster.local:3306       # read-write
<release>-secondary.mysql-cluster.svc.cluster.local:3306     # read-only (LB)
```

### PostgreSQL (`postgres-cluster` namespace)

```
# Headless service name: postgres-headless
<release>-primary-0.postgres-headless.postgres-cluster.svc.cluster.local:5432
<release>-standby-0-0.postgres-headless.postgres-cluster.svc.cluster.local:5432
<release>-standby-1-0.postgres-headless.postgres-cluster.svc.cluster.local:5432

# ClusterIP services
<release>-primary.postgres-cluster.svc.cluster.local:5432    # read-write
<release>-standby.postgres-cluster.svc.cluster.local:5432    # read-only (LB)
```

### Redis (`redis` namespace)

```
# Headless service name: redis-headless
redis-primary-0.redis-headless.redis.svc.cluster.local:6379
redis-replica-1-0.redis-headless.redis.svc.cluster.local:6379
redis-replica-2-0.redis-headless.redis.svc.cluster.local:6379
redis-sentinel-0.redis-headless.redis.svc.cluster.local:26379
redis-sentinel-1.redis-headless.redis.svc.cluster.local:26379
redis-sentinel-2.redis-headless.redis.svc.cluster.local:26379

# ClusterIP services
redis-primary.redis.svc.cluster.local:6379      # writes (static label)
redis-replica.redis.svc.cluster.local:6379      # reads (LB)
redis-sentinel.redis.svc.cluster.local:26379    # Sentinel discovery
```

---

## Replication Validation

### MySQL — Group Replication

```bash
# Check all members are ONLINE
kubectl exec -n mysql-cluster -it <release>-primary-0 -- \
  mysql -uroot -proot -e "
    SELECT MEMBER_HOST, MEMBER_ROLE, MEMBER_STATE
    FROM performance_schema.replication_group_members;"

# Expected output: 3 rows, all MEMBER_STATE=ONLINE, one PRIMARY two SECONDARY

# Verify replication is flowing (check secondary lag)
kubectl exec -n mysql-cluster -it <release>-secondary-0-0 -- \
  mysql -uroot -proot -e "
    SELECT * FROM performance_schema.replication_group_member_stats
    WHERE MEMBER_ID = @@server_uuid\G"
```

### PostgreSQL — Streaming Replication

```bash
# On primary — check standby connections
kubectl exec -n postgres-cluster -it <release>-primary-0 -- \
  psql -U postgres -c "SELECT client_addr, state, sent_lsn, write_lsn,
    flush_lsn, replay_lsn, sync_state FROM pg_stat_replication;"

# On standby — verify it is in recovery mode and connected
kubectl exec -n postgres-cluster -it <release>-standby-0-0 -- \
  psql -U postgres -c "SELECT pg_is_in_recovery(), pg_last_wal_receive_lsn(),
    pg_last_wal_replay_lsn(), pg_last_xact_replay_timestamp();"

# Check replication lag (should be 0 or near-0)
kubectl exec -n postgres-cluster -it <release>-primary-0 -- \
  psql -U postgres -c "
    SELECT application_name,
           pg_size_pretty(pg_wal_lsn_diff(sent_lsn, replay_lsn)) AS lag
    FROM pg_stat_replication;"
```

### Redis — Sentinel + Replication

```bash
# On primary — verify replicas are connected
kubectl exec -n redis -it redis-primary-0 -- \
  redis-cli -a Admin@123 --no-auth-warning INFO replication

# Expected: role:master, connected_slaves:2

# On replica — verify replication is running
kubectl exec -n redis -it redis-replica-1-0 -- \
  redis-cli -a Admin@123 --no-auth-warning INFO replication

# Expected: role:slave, master_link_status:up, master_sync_in_progress:0

# Sentinel — verify it sees the master and replicas
kubectl exec -n redis -it redis-sentinel-0 -- \
  redis-cli -p 26379 SENTINEL masters

kubectl exec -n redis -it redis-sentinel-0 -- \
  redis-cli -p 26379 SENTINEL slaves mymaster
```

---

## Failover Test Procedures

### MySQL — Group Replication Auto-Failover

GR uses Paxos majority (2-of-3) to elect a new primary automatically.
Expected total failover time: **10–20 seconds** (expel timeout 5s + election 5s + reconnect).

```bash
# Step 1: Create test data on primary
kubectl exec -n mysql-cluster -it <release>-primary-0 -- \
  mysql -uroot -proot -e "
    CREATE DATABASE IF NOT EXISTS failover_test;
    CREATE TABLE IF NOT EXISTS failover_test.events
      (id SERIAL PRIMARY KEY, msg TEXT, ts DATETIME DEFAULT NOW());
    INSERT INTO failover_test.events (msg) VALUES ('before-failover');"

# Step 2: Confirm secondaries are ONLINE
kubectl exec -n mysql-cluster -it <release>-secondary-0-0 -- \
  mysql -uroot -proot -e "SELECT MEMBER_HOST, MEMBER_ROLE, MEMBER_STATE
    FROM performance_schema.replication_group_members;"

# Step 3: Kill the primary pod
kubectl delete pod -n mysql-cluster <release>-primary-0

# Step 4: Watch secondaries elect a new GR primary (should take ~15s)
kubectl exec -n mysql-cluster -it <release>-secondary-0-0 -- \
  mysql -uroot -proot -e "SELECT MEMBER_HOST, MEMBER_ROLE, MEMBER_STATE
    FROM performance_schema.replication_group_members;"
# One of the secondaries now shows MEMBER_ROLE=PRIMARY

# Step 5: Write to the NEW primary (whichever secondary was elected)
NEW_PRIMARY=$(kubectl exec -n mysql-cluster -it <release>-secondary-0-0 -- \
  mysql -uroot -proot -sN -e "
    SELECT SUBSTRING_INDEX(MEMBER_HOST,'.',1)
    FROM performance_schema.replication_group_members
    WHERE MEMBER_ROLE='PRIMARY';" 2>/dev/null | tr -d '\r')
echo "New primary: ${NEW_PRIMARY}"

kubectl exec -n mysql-cluster -it <release>-secondary-0-0 -- \
  mysql -uroot -proot -e "
    INSERT INTO failover_test.events (msg) VALUES ('after-failover');
    SELECT * FROM failover_test.events;"

# Step 6: Wait for original primary pod to restart and rejoin as secondary
kubectl get pods -n mysql-cluster -w
# bootstrap.sh detects group is running and JOINs (does not re-bootstrap)

# Step 7: Verify data is consistent across all members
for pod in <release>-primary-0 <release>-secondary-0-0 <release>-secondary-1-0; do
  echo "=== $pod ===";
  kubectl exec -n mysql-cluster -it $pod -- \
    mysql -uroot -proot -e "SELECT * FROM failover_test.events;" 2>/dev/null;
done
```

### PostgreSQL — Standby Promotion (Manual + Monitoring)

PostgreSQL streaming replication provides hot standbys. Standbys do NOT auto-promote
on primary failure (unlike Patroni/Repmgr). Promotion is manual or via an operator.

```bash
# Step 1: Create test data on primary
kubectl exec -n postgres-cluster -it <release>-primary-0 -- \
  psql -U postgres -c "
    CREATE TABLE IF NOT EXISTS failover_test (
      id SERIAL PRIMARY KEY, msg TEXT, ts TIMESTAMPTZ DEFAULT NOW());
    INSERT INTO failover_test (msg) VALUES ('before-failover');"

# Step 2: Confirm standbys are in recovery with replication active
kubectl exec -n postgres-cluster -it <release>-primary-0 -- \
  psql -U postgres -c "SELECT * FROM pg_stat_replication;"

# Step 3: Kill the primary pod
kubectl delete pod -n postgres-cluster <release>-primary-0

# Step 4: Standbys continue in hot_standby mode (read-only, still available)
kubectl exec -n postgres-cluster -it <release>-standby-0-0 -- \
  psql -U postgres -c "SELECT pg_is_in_recovery(); SELECT * FROM failover_test;"

# Step 5: Promote standby-0 to new primary
kubectl exec -n postgres-cluster -it <release>-standby-0-0 -- \
  gosu postgres pg_ctl promote -D /var/lib/postgresql/data/pgdata

# Step 6: Verify promotion succeeded
kubectl exec -n postgres-cluster -it <release>-standby-0-0 -- \
  psql -U postgres -c "SELECT pg_is_in_recovery();"
# Expected: f (false = primary mode)

# Step 7: Write to promoted primary
kubectl exec -n postgres-cluster -it <release>-standby-0-0 -- \
  psql -U postgres -c "INSERT INTO failover_test (msg) VALUES ('after-failover');
    SELECT * FROM failover_test;"

# Step 8: Verify data — standby-1 should still replicate (if configured to new primary)
# NOTE: standby-1 still points to the OLD primary FQDN. To repoint it:
kubectl exec -n postgres-cluster -it <release>-standby-1-0 -- bash -c "
  gosu postgres psql -c \"ALTER SYSTEM SET primary_conninfo =
    'host=<release>-standby-0-0.postgres-headless.postgres-cluster.svc.cluster.local
     port=5432 user=replicator password=\$(cat /run/secrets/...)';\"
  gosu postgres pg_ctl reload -D /var/lib/postgresql/data/pgdata"
```

### Redis — Sentinel Auto-Failover

Sentinel monitors the primary and automatically promotes a replica when quorum agrees.
Expected failover time: **5–15 seconds** (downAfterMs=5000ms + promotion + reconnect).

```bash
# Step 1: Write test data to primary
kubectl exec -n redis -it redis-primary-0 -- \
  redis-cli -a Admin@123 --no-auth-warning SET failover_test "before"

# Confirm replication is active
kubectl exec -n redis -it redis-primary-0 -- \
  redis-cli -a Admin@123 --no-auth-warning INFO replication | grep -E "role:|connected_slaves:|slave"

# Step 2: Ask Sentinel who the current master is
kubectl exec -n redis -it redis-sentinel-0 -- \
  redis-cli -p 26379 SENTINEL get-master-addr-by-name mymaster

# Step 3: Kill the primary pod
kubectl delete pod -n redis redis-primary-0

# Step 4: Watch Sentinel elect a new master (~5-15s)
watch -n 2 'kubectl exec -n redis -it redis-sentinel-0 -- \
  redis-cli -p 26379 SENTINEL get-master-addr-by-name mymaster 2>/dev/null'

# Step 5: Verify the promoted replica now reports role:master
kubectl exec -n redis -it redis-replica-1-0 -- \
  redis-cli -a Admin@123 --no-auth-warning INFO replication | grep role

# Step 6: Test data survived failover
kubectl exec -n redis -it redis-replica-1-0 -- \
  redis-cli -a Admin@123 --no-auth-warning GET failover_test
# Expected: "before"

# Step 7: Write to new master
kubectl exec -n redis -it redis-replica-1-0 -- \
  redis-cli -a Admin@123 --no-auth-warning SET failover_test "after"

# Step 8: Original primary restarts and auto-rejoins as replica
kubectl get pods -n redis -w
kubectl exec -n redis -it redis-primary-0 -- \
  redis-cli -a Admin@123 --no-auth-warning INFO replication | grep role
# Expected: role:slave (demoted to replica by Sentinel)

# Step 9: Confirm data replicated to all nodes
for pod in redis-primary-0 redis-replica-1-0 redis-replica-2-0; do
  echo "=== $pod ===";
  kubectl exec -n redis -it $pod -- \
    redis-cli -a Admin@123 --no-auth-warning GET failover_test 2>/dev/null;
done
```

---

## Architecture Notes

### MySQL Group Replication

- **Protocol**: Paxos-based synchronous multi-primary replication (single-primary mode)
- **Automatic failover**: Yes — 2 remaining members elect a new primary in ~10s
- **Split-brain prevention**: `bootstrap.sh` detects existing group on restart and JOINs
  instead of bootstrapping a new group
- **GR port**: 33061 (XCOM) — excluded from Consul/Envoy interception
- **Read scaling**: Route reads to `<release>-secondary` ClusterIP service

### PostgreSQL Streaming Replication

- **Protocol**: WAL streaming — standbys apply WAL segments from primary
- **Automatic failover**: No — requires manual `pg_ctl promote` or an operator (Patroni)
- **Hot standby**: Read-only queries work on standbys during normal operation and
  after primary failure (until promoted)
- **Fresh standby init**: `pg_basebackup` runs on first pod start with empty PVC
- **Data safety**: Synchronous or async WAL — `synchronous_standby_names` can be
  set to guarantee zero data loss (not set by default to avoid write latency)

### Redis Sentinel HA

- **Protocol**: Async master→replica PSYNC2 streaming replication
- **Automatic failover**: Yes — Sentinel quorum=2 promotes a replica in ~5-15s
- **FQDN-based failover**: `announce-hostnames yes` ensures replicas reconnect to
  promoted master by FQDN (not IP), which is stable across pod restarts
- **AOF persistence**: `appendonly yes` with `appendfsync everysec` — at most 1s
  data loss on crash (can set `always` for zero data loss at higher I/O cost)
- **Client pattern**: Use `redis-sentinel.redis.svc.cluster.local:26379` with
  Sentinel-aware client library; call `SENTINEL get-master-addr-by-name mymaster`
  to discover the current master before connecting

### Policy Routing Tables (All Charts)

All pods run a `fix-routing` init container that sets up Linux policy routing:

| Table | Rule | Purpose |
|-------|------|---------|
| `100` | `from <eth0-IP> lookup 100` | Envoy readiness probe asymmetric reply fix |
| `200` | `from/to 192.168.9.0/24 lookup 200` | MacVLAN reply traffic via net1 (primary only) |

This prevents MacVLAN from hijacking the default route and breaking DNS, Consul,
K8s API, and Envoy probes.

---

## Troubleshooting

```bash
# Check init container logs (fix-routing / consul-tag-patcher)
kubectl logs -n <namespace> <pod> -c fix-routing
kubectl logs -n <namespace> <pod> -c consul-tag-patcher

# MySQL: why is a member not ONLINE?
kubectl exec -n mysql-cluster -it <pod> -- \
  mysql -uroot -proot -e "SELECT * FROM performance_schema.replication_group_members;
    SHOW REPLICA STATUS\G"

# Postgres: standby not connecting?
kubectl exec -n postgres-cluster -it <standby-pod> -- \
  tail -50 /var/lib/postgresql/data/pgdata/log/*.log 2>/dev/null || \
  kubectl logs -n postgres-cluster <standby-pod>

# Redis: sentinel not detecting master?
kubectl exec -n redis -it redis-sentinel-0 -- \
  redis-cli -p 26379 SENTINEL masters
kubectl exec -n redis -it redis-sentinel-0 -- \
  redis-cli -p 26379 SENTINEL sentinels mymaster
```
